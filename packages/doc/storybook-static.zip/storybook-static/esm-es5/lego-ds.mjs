import { p as patchBrowser, b as bootstrapLazy } from './index-88971d1c.js';
import { g as globalScripts } from './app-globals-54c21265.js';
patchBrowser().then(function (options) {
    globalScripts();
    return bootstrapLazy([["legods-button_4", [[1, "legods-button", { "styles": [8], "variant": [1], "disabled": [4], "full": [4], "flat": [4] }, [[2, "click", "handleClick"]]], [1, "legods-input", { "label": [1], "value": [1], "inputId": [1, "input-id"], "name": [1], "disabled": [4] }], [1, "soma-checkbox", { "checked": [4], "inverse": [4], "disabled": [4], "value": [8], "label": [1], "ariaLabel": [1, "aria-label"] }], [1, "soma-text-field", { "type": [1], "message": [1], "feedback": [1], "inputId": [1, "input-id"], "label": [1], "value": [1], "disabled": [4], "name": [1], "icon": [1], "ariaLabel": [1, "aria-label"], "inputFocus": [32] }]]]], options);
});
