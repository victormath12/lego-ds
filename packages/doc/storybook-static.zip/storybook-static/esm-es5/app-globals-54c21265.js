/**
 * Import fonts.
 *
 * @export
 */
function importFonts() {
    var link1 = document.createElement("link");
    link1.rel = "stylesheet";
    link1.href = "https://fonts.googleapis.com/css2?family=Montserrat:wght@500;700;800&display=swap";
    var link2 = document.createElement("link");
    link2.rel = "stylesheet";
    link2.href = "https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700&display=swap";
    var link3 = document.createElement("link");
    link3.rel = "stylesheet";
    link3.href = "https://fonts.googleapis.com/css?family=Roboto+Slab:400,500,600,700&display=swap";
    document.head.appendChild(link1);
    document.head.appendChild(link2);
    document.head.appendChild(link3);
}
// import { ThemeProvider } from 'chameleon';
/*
SomaDS.on('change', (theme) => {
  ThemeProvider.setValue(theme)
});

const shouldSetDefaultTheme = true;
*/
var appGlobalScript = function () {
    /*
    if(shouldSetDefaultTheme) {
      SomaDS.use('placeholder');
    }
    */
    importFonts();
};
var globalScripts = appGlobalScript;
export { globalScripts as g };
