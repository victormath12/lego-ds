import{r as t,c as e,h as o,H as s,g as i}from"./p-9285c76b.js";const r=t=>{if(t){n(t);const e=t.length;return Object.keys(t).reduce((o,s)=>{try{if(parseInt(s)<e){const e=t[s];return Object.assign(Object.assign({},o),{[e.name]:e.value})}}catch(i){}},{})}return{}},n=t=>{const e=/(_ngcontent-|data-v-)/g;Object.values(t).filter(t=>t.name.match(e)).forEach(e=>{t.removeNamedItem(e.name)})};class a{constructor(o){t(this,o),this.styles={},this.variant="",this.disabled=!1,this.full=!1,this.flat=!1,this.component={name:"legods-button",properties:r(this.el.attributes),styles:this.styles},this.buttonClick=e(this,"buttonClick",7)}handleClick(t){!this.disabled&&this.buttonClick.emit(((t,e,o)=>({component:e.name,props:Object.assign(Object.assign({},e.properties),{styles:e.styles}),eventName:"buttonClick",event:o}))(0,this.component,t))}render(){return o(s,{style:this.full&&{width:"100%"}},o("button",Object.assign({},r(this.el.attributes),{class:`\n            legods-button \n            ${this.variant&&this.variant} \n            ${this.full&&"full"} \n            ${this.flat&&"flat"} \n          `,style:this.styles,disabled:this.disabled}),o("slot",null)))}get el(){return i(this)}}a.style=':host{position:relative;display:block;-webkit-box-sizing:border-box;box-sizing:border-box;width:-webkit-fit-content;width:-moz-fit-content;width:fit-content}.legods-button{position:relative;width:-webkit-fit-content;width:-moz-fit-content;width:fit-content;padding:10px 16px;background:#FFF;border:2px solid #18191F;-webkit-box-sizing:border-box;box-sizing:border-box;-webkit-box-shadow:0px 4px 0px #18191F;box-shadow:0px 4px 0px #18191F;border-radius:16px;font-family:"Montserrat", "Tahoma";font-style:normal;font-weight:800;font-size:16px;line-height:20px;color:#18191F;outline:none;cursor:pointer;}.legods-button.full{width:100%}.legods-button.flat{-webkit-box-shadow:none;box-shadow:none}.legods-button.primary{background:#F95A2C}.legods-button.secondary{background:#FFBD12}.legods-button.tertiary{background:#1947E6;color:#FFF}.legods-button.dark{background:#000;color:#FFF}.legods-button:not(:disabled):not(.flat):hover,.legods-button:not(:disabled):not(.flat):focus{-webkit-box-shadow:0px 2px 0px #18191F;box-shadow:0px 2px 0px #18191F;top:2px}.legods-button:not(:disabled):not(.flat):active{-webkit-box-shadow:0px 0px 0px #18191F;box-shadow:0px 0px 0px #18191F;top:4px}.legods-button:not(:disabled).flat:hover,.legods-button:not(:disabled).flat:focus{background:#F4F5F7}.legods-button:not(:disabled).flat.primary:hover,.legods-button:not(:disabled).flat.primary:focus{background:#F95A2CB3}.legods-button:not(:disabled).flat.secondary:hover,.legods-button:not(:disabled).flat.secondary:focus{background:#FFBD12B3}.legods-button:not(:disabled).flat.tertiary:hover,.legods-button:not(:disabled).flat.tertiary:focus{background:#1947E6B3;color:#FFF}.legods-button:not(:disabled).flat.dark:hover,.legods-button:not(:disabled).flat.dark:focus{background:#000000B3;color:#FFF}.legods-button:not(:disabled).flat:active{background:#EEEFF4}.legods-button:not(:disabled).flat.primary:active{background:#F95A2C80}.legods-button:not(:disabled).flat.secondary:active{background:#FFBD1280}.legods-button:not(:disabled).flat.tertiary:active{background:#1947E680;color:#FFF}.legods-button:not(:disabled).flat.dark:active{background:#00000080;color:#FFF}.legods-button:disabled{opacity:0.6;cursor:not-allowed;background:#EEEFF4;border:2px solid #CCCCCC;color:#474A57}.legods-button:not(.flat):disabled{-webkit-box-shadow:0px 4px 0px #CCCCCC;box-shadow:0px 4px 0px #CCCCCC}';class c{constructor(e){t(this,e),this.disabled=!1}render(){return o(s,null,o("h1",null,"Hey"))}get el(){return i(this)}}async function l(t,e){for(const o of e.__requiredProperties)null==e[o]&&console.error(`[${t}] Missing required property '${o}'.`)}c.style=":host{position:relative;display:block;-webkit-box-sizing:border-box;box-sizing:border-box;width:-webkit-fit-content;width:-moz-fit-content;width:fit-content}.legods-input{position:relative;width:-webkit-fit-content;width:-moz-fit-content;width:fit-content;padding:10px 16px;width:100px;height:200px;background:#ddd}";const u=()=>(t,e)=>{if(t.__requiredProperties=t.__requiredProperties||[],t.__requiredProperties.push(e),t.__renderOverrided)return;t.__renderOverrided=!0;const o=t.render;t.render=function(){return l(t.constructor.name,this),o.apply(this,arguments)}};/Edge\/\d./i.test(navigator.userAgent)||/rv:11.0/i.test(navigator.userAgent),!!window.MSInputMethodContext&&document;class b{static subscribe(t,e){if(this.callbacks[t])return this.callbacks[t].push(e);this.callbacks[t]=[e]}static emit(t,e){(this.callbacks[t]||[]).forEach(t=>{t(e)}),this.callbacks[t]=void 0}}b.callbacks={};class d{static getIcon(t,e){return new Promise((o,s)=>{this.url||s("you should set url");const i=this.getKey(e,t),r=this.cache.get(i);if("waiting"==r)return b.subscribe(i,t=>o(t));if(null!=r)return o(r);const n=new XMLHttpRequest;n.onreadystatechange=()=>{if(4==n.readyState)return 200===n.status?(this.cache.set(i,n.response),b.emit(i,n.response),o(n.response)):void s(`Error trying to import ${e} ${t}`)},null==r&&(this.cache.set(i,"waiting"),n.open("GET",`${this.url}/${t}/${e}.svg`,!0),n.send())})}static getKey(t,e){return`${e}#${t}`}}d.cache=new Map;const h={combine:function(t){let e=Array.isArray(t.root)?t.root.join(" "):t.root;if(null==t.conditions)return e;for(const[o,s]of Object.entries(t.conditions))"boolean"==typeof s&&s?e+=" "+o:"function"==typeof s?e+=" "+s():"string"==typeof s&&s&&(e+=" "+s);return e}};function f(t){function e(t,e,s){var i=e.trim().split(f);e=i;var r=i.length,n=t.length;switch(n){case 0:case 1:var a=0;for(t=0===n?"":t[0]+" ";a<r;++a)e[a]=o(t,e[a],s).trim();break;default:var c=a=0;for(e=[];a<r;++a)for(var l=0;l<n;++l)e[c++]=o(t[l]+" ",i[a],s).trim()}return e}function o(t,e,o){var s=e.charCodeAt(0);switch(33>s&&(s=(e=e.trim()).charCodeAt(0)),s){case 38:return e.replace(k,"$1"+t.trim());case 58:return t.trim()+e.replace(k,"$1"+t.trim());default:if(0<1*o&&0<e.indexOf("\f"))return e.replace(k,(58===t.charCodeAt(0)?"":"$1")+t.trim())}return t+e}function s(t,e,o,r){var n=t+";",a=2*e+3*o+4*r;if(944===a){t=n.indexOf(":",9)+1;var c=n.substring(t,n.length-1).trim();return c=n.substring(0,t).trim()+c+";",1===E||2===E&&i(c,1)?"-webkit-"+c+c:c}if(0===E||2===E&&!i(n,1))return n;switch(a){case 1015:return 97===n.charCodeAt(10)?"-webkit-"+n+n:n;case 951:return 116===n.charCodeAt(3)?"-webkit-"+n+n:n;case 963:return 110===n.charCodeAt(5)?"-webkit-"+n+n:n;case 1009:if(100!==n.charCodeAt(4))break;case 969:case 942:return"-webkit-"+n+n;case 978:return"-webkit-"+n+"-moz-"+n+n;case 1019:case 983:return"-webkit-"+n+"-moz-"+n+"-ms-"+n+n;case 883:if(45===n.charCodeAt(8))return"-webkit-"+n+n;if(0<n.indexOf("image-set(",11))return n.replace(C,"$1-webkit-$2")+n;break;case 932:if(45===n.charCodeAt(4))switch(n.charCodeAt(5)){case 103:return"-webkit-box-"+n.replace("-grow","")+"-webkit-"+n+"-ms-"+n.replace("grow","positive")+n;case 115:return"-webkit-"+n+"-ms-"+n.replace("shrink","negative")+n;case 98:return"-webkit-"+n+"-ms-"+n.replace("basis","preferred-size")+n}return"-webkit-"+n+"-ms-"+n+n;case 964:return"-webkit-"+n+"-ms-flex-"+n+n;case 1023:if(99!==n.charCodeAt(8))break;return"-webkit-box-pack"+(c=n.substring(n.indexOf(":",15)).replace("flex-","").replace("space-between","justify"))+"-webkit-"+n+"-ms-flex-pack"+c+n;case 1005:return d.test(n)?n.replace(b,":-webkit-")+n.replace(b,":-moz-")+n:n;case 1e3:switch(e=(c=n.substring(13).trim()).indexOf("-")+1,c.charCodeAt(0)+c.charCodeAt(e)){case 226:c=n.replace(g,"tb");break;case 232:c=n.replace(g,"tb-rl");break;case 220:c=n.replace(g,"lr");break;default:return n}return"-webkit-"+n+"-ms-"+c+n;case 1017:if(-1===n.indexOf("sticky",9))break;case 975:switch(e=(n=t).length-10,a=(c=(33===n.charCodeAt(e)?n.substring(0,e):n).substring(t.indexOf(":",7)+1).trim()).charCodeAt(0)+(0|c.charCodeAt(7))){case 203:if(111>c.charCodeAt(8))break;case 115:n=n.replace(c,"-webkit-"+c)+";"+n;break;case 207:case 102:n=n.replace(c,"-webkit-"+(102<a?"inline-":"")+"box")+";"+n.replace(c,"-webkit-"+c)+";"+n.replace(c,"-ms-"+c+"box")+";"+n}return n+";";case 938:if(45===n.charCodeAt(5))switch(n.charCodeAt(6)){case 105:return c=n.replace("-items",""),"-webkit-"+n+"-webkit-box-"+c+"-ms-flex-"+c+n;case 115:return"-webkit-"+n+"-ms-flex-item-"+n.replace($,"")+n;default:return"-webkit-"+n+"-ms-flex-line-pack"+n.replace("align-content","").replace($,"")+n}break;case 973:case 989:if(45!==n.charCodeAt(3)||122===n.charCodeAt(4))break;case 931:case 953:if(!0===F.test(t))return 115===(c=t.substring(t.indexOf(":")+1)).charCodeAt(0)?s(t.replace("stretch","fill-available"),e,o,r).replace(":fill-available",":stretch"):n.replace(c,"-webkit-"+c)+n.replace(c,"-moz-"+c.replace("fill-",""))+n;break;case 962:if(n="-webkit-"+n+(102===n.charCodeAt(5)?"-ms-"+n:"")+n,211===o+r&&105===n.charCodeAt(13)&&0<n.indexOf("transform",10))return n.substring(0,n.indexOf(";",27)+1).replace(h,"$1-webkit-$2")+n}return n}function i(t,e){var o=t.indexOf(1===e?":":"{"),s=t.substring(0,3!==e?o:10);return o=t.substring(o+1,t.length-1),B(2!==e?s:s.replace(y,"$1"),o,e)}function r(t,e){var o=s(e,e.charCodeAt(0),e.charCodeAt(1),e.charCodeAt(2));return o!==e+";"?o.replace(v," or ($1)").substring(4):"("+e+")"}function n(t,e,o,s,i,r,n,a,l,u){for(var b,d=0,h=e;d<L;++d)switch(b=R[d].call(c,t,h,o,s,i,r,n,a,l,u)){case void 0:case!1:case!0:case null:break;default:h=b}if(h!==e)return h}function a(t){return void 0!==(t=t.prefix)&&(B=null,t?"function"!=typeof t?E=1:(E=2,B=t):E=0),a}function c(t,o){var a=t;if(33>a.charCodeAt(0)&&(a=a.trim()),a=[a],0<L){var c=n(-1,o,a,a,S,z,0,0,0,0);void 0!==c&&"string"==typeof c&&(o=c)}var b=function t(o,a,c,b,d){for(var h,f,k,g,v,$=0,y=0,F=0,C=0,R=0,B=0,Y=k=h=0,M=0,_=0,H=0,T=0,U=c.length,D=U-1,I="",W="",q="",J="";M<U;){if(f=c.charCodeAt(M),M===D&&0!==y+C+F+$&&(0!==y&&(f=47===y?10:47),C=F=$=0,U++,D++),0===y+C+F+$){if(M===D&&(0<_&&(I=I.replace(u,"")),0<I.trim().length)){switch(f){case 32:case 9:case 59:case 13:case 10:break;default:I+=c.charAt(M)}f=59}switch(f){case 123:for(h=(I=I.trim()).charCodeAt(0),k=1,T=++M;M<U;){switch(f=c.charCodeAt(M)){case 123:k++;break;case 125:k--;break;case 47:switch(f=c.charCodeAt(M+1)){case 42:case 47:t:{for(Y=M+1;Y<D;++Y)switch(c.charCodeAt(Y)){case 47:if(42===f&&42===c.charCodeAt(Y-1)&&M+2!==Y){M=Y+1;break t}break;case 10:if(47===f){M=Y+1;break t}}M=Y}}break;case 91:f++;case 40:f++;case 34:case 39:for(;M++<D&&c.charCodeAt(M)!==f;);}if(0===k)break;M++}switch(k=c.substring(T,M),0===h&&(h=(I=I.replace(l,"").trim()).charCodeAt(0)),h){case 64:switch(0<_&&(I=I.replace(u,"")),f=I.charCodeAt(1)){case 100:case 109:case 115:case 45:_=a;break;default:_=O}if(T=(k=t(a,_,k,f,d+1)).length,0<L&&(v=n(3,k,_=e(O,I,H),a,S,z,T,f,d,b),I=_.join(""),void 0!==v&&0===(T=(k=v.trim()).length)&&(f=0,k="")),0<T)switch(f){case 115:I=I.replace(w,r);case 100:case 109:case 45:k=I+"{"+k+"}";break;case 107:k=(I=I.replace(p,"$1 $2"))+"{"+k+"}",k=1===E||2===E&&i("@"+k,3)?"@-webkit-"+k+"@"+k:"@"+k;break;default:k=I+k,112===b&&(W+=k,k="")}else k="";break;default:k=t(a,e(a,I,H),k,b,d+1)}q+=k,k=H=_=Y=h=0,I="",f=c.charCodeAt(++M);break;case 125:case 59:if(1<(T=(I=(0<_?I.replace(u,""):I).trim()).length))switch(0===Y&&(h=I.charCodeAt(0),45===h||96<h&&123>h)&&(T=(I=I.replace(" ",":")).length),0<L&&void 0!==(v=n(1,I,a,o,S,z,W.length,b,d,b))&&0===(T=(I=v.trim()).length)&&(I="\0\0"),h=I.charCodeAt(0),f=I.charCodeAt(1),h){case 0:break;case 64:if(105===f||99===f){J+=I+c.charAt(M);break}default:58!==I.charCodeAt(T-1)&&(W+=s(I,h,f,I.charCodeAt(2)))}H=_=Y=h=0,I="",f=c.charCodeAt(++M)}}switch(f){case 13:case 10:47===y?y=0:0===1+h&&107!==b&&0<I.length&&(_=1,I+="\0"),0<L*A&&n(0,I,a,o,S,z,W.length,b,d,b),z=1,S++;break;case 59:case 125:if(0===y+C+F+$){z++;break}default:switch(z++,g=c.charAt(M),f){case 9:case 32:if(0===C+$+y)switch(R){case 44:case 58:case 9:case 32:g="";break;default:32!==f&&(g=" ")}break;case 0:g="\\0";break;case 12:g="\\f";break;case 11:g="\\v";break;case 38:0===C+y+$&&(_=H=1,g="\f"+g);break;case 108:if(0===C+y+$+j&&0<Y)switch(M-Y){case 2:112===R&&58===c.charCodeAt(M-3)&&(j=R);case 8:111===B&&(j=B)}break;case 58:0===C+y+$&&(Y=M);break;case 44:0===y+F+C+$&&(_=1,g+="\r");break;case 34:case 39:0===y&&(C=C===f?0:0===C?f:C);break;case 91:0===C+y+F&&$++;break;case 93:0===C+y+F&&$--;break;case 41:0===C+y+$&&F--;break;case 40:if(0===C+y+$){if(0===h)switch(2*R+3*B){case 533:break;default:h=1}F++}break;case 64:0===y+F+C+$+Y+k&&(k=1);break;case 42:case 47:if(!(0<C+$+F))switch(y){case 0:switch(2*f+3*c.charCodeAt(M+1)){case 235:y=47;break;case 220:T=M,y=42}break;case 42:47===f&&42===R&&T+2!==M&&(33===c.charCodeAt(T+2)&&(W+=c.substring(T,M+1)),g="",y=0)}}0===y&&(I+=g)}B=R,R=f,M++}if(0<(T=W.length)){if(_=a,0<L&&void 0!==(v=n(2,W,_,o,S,z,T,b,d,b))&&0===(W=v).length)return J+W+q;if(W=_.join(",")+"{"+W+"}",0!=E*j){switch(2!==E||i(W,2)||(j=0),j){case 111:W=W.replace(x,":-moz-$1")+W;break;case 112:W=W.replace(m,"::-webkit-input-$1")+W.replace(m,"::-moz-$1")+W.replace(m,":-ms-input-$1")+W}j=0}}return J+W+q}(O,a,o,0,0);return 0<L&&void 0!==(c=n(-2,b,a,a,S,z,b.length,0,0,0))&&(b=c),j=0,z=S=1,b}var l=/^\0+/g,u=/[\0\r\f]/g,b=/: */g,d=/zoo|gra/,h=/([,: ])(transform)/g,f=/,\r+?/g,k=/([\t\r\n ])*\f?&/g,p=/@(k\w+)\s*(\S*)\s*/,m=/::(place)/g,x=/:(read-only)/g,g=/[svh]\w+-[tblr]{2}/,w=/\(\s*(.*)\s*\)/g,v=/([\s\S]*?);/g,$=/-self|flex-/g,y=/[^]*?(:[rp][el]a[\w-]+)[^]*/,F=/stretch|:\s*\w+\-(?:conte|avail)/,C=/([^-])(image-set\()/,z=1,S=1,j=0,E=1,O=[],R=[],L=0,B=null,A=0;return c.use=function t(e){switch(e){case void 0:case null:L=R.length=0;break;default:if("function"==typeof e)R[L++]=e;else if("object"==typeof e)for(var o=0,s=e.length;o<s;++o)t(e[o]);else A=0|!!e}return t},c.set=a,void 0!==t&&a(t),c}function k(t,e){const o=[];let s=-1;for(;-1!=(s=t.indexOf(e,s+1));)o.push(s);return o}function p(t,e){const o=e.split(".");let s,i=t;for(;(s=o.shift())&&(i=i[s],null!=i););return null!=i?i:null}const m={get(t){return p(this,t)},if(t,e,o,s){return p(this,t)===e?o:s||null},switch(t,e){return e[p(this,t)]||null}};class x{constructor(t,e){this._listener=t,this._removeHandler=e}unsubscribe(){this._removeHandler(this._listener)}}let g=new class extends class{constructor(t){this._listeners={},this._listenerIdx=0,this._state=this.parseState(t)}subscribe(t){const e=this._listenerIdx++;return t.__subscriptionId=e,this._listeners[e]=t,new x(t,this.removeListener.bind(this))}removeListener(t){delete this._listeners[t.__subscriptionId]}next(t){this._state=this.parseState(t);for(const e in this._listeners)(0,this._listeners[e])(this._state)}parseState(t){return Object.assign({},this._state,t)}}{get theme(){return this._state}setValue(t){this.next(t)}}({});var w;!function(t){t[t.PlainText=0]="PlainText",t[t.StyleElement=1]="StyleElement",t[t.Constructable=2]="Constructable"}(w||(w={}));class v{static get(t){return this.table[t]}static set(t,e){return this.table[t]={value:e,count:1}}static del(t,e){if(e===w.StyleElement){const e=this.table[t],o=document.querySelector(`style[constructable-style=${null==e?void 0:e.value}]`);null==o||o.remove()}return delete this.table[t]}static moveUsage(t,e,o){this.incUsage(e),this.decUsage(t,o)}static decUsage(t,e){const o=this.get(t);null!=o&&(o.count--,0===o.count&&this.del(t,e))}static incUsage(t){this.get(t).count++}}v.table={};let $=0;const y=new class{constructor(t){this.stylis=new f(t)}build(t,e,o){let s=this.stylis(t,e);return o&&(s=function(t){const e={host:":host(",slotted:"::slotted("},o={host:k(t,e.host),slotted:k(t,e.slotted)},s={host:new Set,slotted:new Set};return Object.entries(o).forEach(([e,o])=>{o.forEach(o=>{for(var i=o;")"!==t[i];)i++;s[e].add(t.substr(o,i-o+1))})}),Object.entries(s).forEach(([o,s])=>{s.forEach(s=>{t=t.split(s).join(s.slice(e[o].length).slice(0,-1))})}),t}(s)),s}};function F(t,e,o,s){var i;const r=o.css(function(t){const e={theme:g.theme};e.if=m.if.bind(e),e.get=m.get.bind(e),e.switch=m.switch.bind(e);for(const o in t)"string"!=typeof t[o]&&"number"!=typeof t[o]||(e[o]=t[o]);return e}(e),o.markup),n=null===(i=v.get(r.key))||void 0===i?void 0:i.value;return n&&function(t,e){return e===w.Constructable?t instanceof CSSStyleSheet:e===w.StyleElement?"string"==typeof t&&t.match("chameleon-cp"):e===w.PlainText?"string"==typeof t:void 0}(n,s)?(v.moveUsage(e.__key,r.key,s),e.__key=r.key,n):(null!=e.__key&&v.decUsage(e.__key,s),e.__key=r.key,s===w.StyleElement?function(t,e){const o=function(t){return $++,t.__className="chameleon-cp-"+$,t.__className}(t),s=y.build("."+o,e.skin,!0),i=document.createElement("style");return i.setAttribute("type","text/css"),i.setAttribute("constructable-style",o),i.innerHTML=s,document.head.appendChild(i),v.set(e.key,o),o}(e,r):s===w.Constructable?function(t){const e=y.build("",t.skin),o=new CSSStyleSheet;return o.replace(e),v.set(t.key,o),o}(r):s===w.PlainText?function(t){const e=y.build("",t.skin);return v.set(t.key,e),e}(r):void console.warn("Cannot find strategy to resolve stylesheet"))}function C(t,e,...o){return"function"==typeof t?t.apply(e,o):null}function z(t,e,o){const s=i(e),r=s.shadowRoot||s,n=F(0,e,o,w.Constructable);null!=n&&(r.adoptedStyleSheets=[n])}function S(t){return(e,o)=>{!function(t){t.componentWillLoad&&t.componentWillUpdate&&t.connectedCallback&&t.disconnectedCallback||console.warn(`Chameleon requires you to have somes lifecycle methods in \`${t.constructor.name}\`. Failure to add this function may cause Chameleon to fail due to StencilJS build optimizations.`)}(e),"render"!==o&&console.warn("You should apply 'Adapt' decorator in 'render' method."),function(){try{return!!new CSSStyleSheet}catch(t){return!1}}()?function(t,e){const o=t.componentWillLoad,s=t.componentWillUpdate,r=t.connectedCallback,n=t.disconnectedCallback;t.componentWillLoad=function(){C(o,this),z(0,this,e)},t.componentWillUpdate=function(){C(s,this),z(0,this,e)},t.connectedCallback=function(){const a=i(this);return null===a.shadowRoot?(t.componentWillLoad=o,t.componentWillUpdate=s,t.connectedCallback=r,t.disconnectedCallback=n,j(t,e),t.connectedCallback.apply(this)):(e.markup||(e.markup=a.tagName),this.__themeSubscription=g.subscribe(()=>{z(0,this,e)}),C(r,this))},t.disconnectedCallback=function(){return this.__themeSubscription.unsubscribe(),C(n,this)}}(e,t):j(e,t)}}function j(t,e){const r=t.connectedCallback,n=t.disconnectedCallback;t.connectedCallback=function(){const t=i(this);e.markup||(e.markup=t.tagName);const n=this.render;return this.render=function(){return function(t,e,r,n){const a=i(e),c=function(t){const e=i(t);return"attachShadow"in HTMLElement.prototype&&null!=e.shadowRoot}(e);let l=r.call(e);if(function(t){for(let e in t)if(t.hasOwnProperty(e)&&t[e]===s)return!0;return!1}(l)||(l=o(s,null,l)),c){const t=F(0,e,n,w.PlainText);!function(t,e,s){(function(t){for(let e in t)if(t.hasOwnProperty(e)&&Array.isArray(t[e]))return t[e];return null}(t)||[]).push(o("style",Object.assign({type:"text/css"},{"constructable-style":e}),s))}(l,n.markup,t),e.__lastRenderer=l}else{const t=F(0,e,n,w.StyleElement);null!=e.__lastClass&&e.__lastClass!==t?(a.classList.remove(e.__lastClass),a.classList.add(t)):null==e.__lastClass&&a.classList.add(t),e.__lastClass=t}return l}(0,this,n,e)},this.__themeSubscription=g.subscribe(()=>function(t,e,o){const s=i(e);if("attachShadow"in HTMLElement.prototype&&null!=s.shadowRoot){const t=F(0,e,o,w.PlainText);if(!e.__lastRenderer)return;for(const o of e.__lastRenderer.t.styleSheets)if(null!=o.ownerNode.getAttribute("constructable-style")){o.ownerNode.innerHTML=t;break}}else if(e.__lastClass){const t=F(0,e,o,w.StyleElement);e.__lastClass!==t&&(s.classList.remove(e.__lastClass),s.classList.add(t),e.__lastClass=t)}}(0,this,e)),C(r,this)},t.disconnectedCallback=function(){return this.__themeSubscription.unsubscribe(),C(n,this)}}function E(t,...e){return(o,s)=>{let i=s;const r=t.reduce((t,s,r)=>{let n=e[r]||"";var a,c,l;return"function"==typeof n?n=n(o):"object"==typeof n&&(a=n,c=new RegExp(",","g"),l=new RegExp(/["{}]/,"g"),n=JSON.stringify(a).replace(c,";").replace(l,"")+";"),i+="$"+n,t+s+n},"");return{key:i,skin:r}}}const O=E`
  :host(.soma-checkbox) {
    display: block;
  }
  :host(.soma-checkbox) label {
    display: flex;
    align-items: center;
    position: relative;
    cursor: pointer;
    font-family: ${t=>t.theme.font.family.base};
    font-weight: ${t=>t.theme.font.weight.regular};
    font-size: ${t=>t.theme.font.size.xxs};
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    color: ${t=>t.theme.color.neutral.dark.pure};
    width: fit-content;
    -webkit-tap-highlight-color: rgba(255, 255, 255, 0);
    -webkit-focus-ring-color: rgba(255, 255, 255, 0);
    outline: none;
  }
  :host(.soma-checkbox) input {
    position: absolute;
    opacity: 0;
    height: 0;
    width: 0;
  }
  :host(.soma-checkbox.inverse) {
    color: ${t=>t.theme.color.neutral.light[1]};
  }
  :host(.soma-checkbox) span {
    margin-left: ${t=>t.theme.spacing.inset.md};
  }
  :host(.soma-checkbox) .checkmark {
    flex-shrink: 0;
    display: inline-block;
    height: 24px;
    width: 24px;
    background-color: ${t=>t.theme.color.neutral.light.pure};
    border-style: ${t=>t.theme.border.style.default};
    border-width: ${t=>t.theme.border.width.thick};
    border-color: ${t=>t.theme.color.neutral.dark[2]};
    box-sizing: border-box;
    transition: 0.1s;
  }
  :host(.soma-checkbox.inverse) .checkmark {
    background-color: ${t=>t.theme.color.neutral.dark.pure};
    border-color: ${t=>t.theme.color.neutral.dark[1]};
  }
  :host(.soma-checkbox.inverse:hover) input ~ .checkmark {
    border-color: ${t=>t.theme.color.neutral.light.pure};
  }
  :host(.soma-checkbox.inverse) input:checked ~ .checkmark {
    background-color: ${t=>t.theme.color.neutral.light.pure};
    border-color: ${t=>t.theme.color.neutral.light.pure};
  }
  :host(.soma-checkbox:hover) input ~ .checkmark {
    border-color: ${t=>t.theme.color.neutral.dark.pure};
  }
  :host(.soma-checkbox.inverse:hover) input ~ .checkmark {
    border-color: ${t=>t.theme.color.neutral.light.pure};
  }
  :host(.soma-checkbox) input:checked ~ .checkmark {
    background-color: ${t=>t.theme.color.neutral.dark.pure};
    border-color: ${t=>t.theme.color.neutral.dark.pure};
  }
  .checkmark:after {
    content: "";
    position: absolute;
    display: none;
  }
  :host(.soma-checkbox) input:checked ~ .checkmark::after {
    display: block;
  }
  :host(.soma-checkbox) .checkmark::after {
    left: 9px;
    top: calc(50% - 7px);
    transform: translateY(-50%);
    width: 5px;
    height: 10px;
    border: solid ${t=>t.theme.color.neutral.light.pure};
    border-width: 0 1.5px 1.5px 0;
    -webkit-transform: rotate(45deg);
    -ms-transform: rotate(45deg);
    transform: rotate(45deg);
  }
  :host(.soma-checkbox.inverse) .checkmark::after {
    border: solid ${t=>t.theme.color.neutral.dark.pure};
    border-width: 0 1.5px 1.5px 0;
  }
  :host(.soma-checkbox.disabled) {
    color: ${t=>t.theme.color.neutral.light[2]};
  }
  :host(.soma-checkbox.disabled) label {
    cursor: default;
  }
  :host(.soma-checkbox.inverse.disabled) {
    color: ${t=>t.theme.color.neutral.dark[2]};
  }
  :host(.soma-checkbox.disabled) .checkmark {
    background-color: ${t=>t.theme.color.neutral.light[1]};
    border-color: ${t=>t.theme.color.neutral.light[2]};
  }
  :host(.soma-checkbox.disabled:hover) input ~ .checkmark {
    background-color: ${t=>t.theme.color.neutral.light[1]};
    border-color: ${t=>t.theme.color.neutral.light[2]};
  }
  :host(.soma-checkbox.inverse.disabled) .checkmark {
    background-color: ${t=>t.theme.color.neutral.dark[3]};
    border-color: ${t=>t.theme.color.neutral.dark[2]};
  }
  :host(.soma-checkbox.inverse.disabled:hover) input ~ .checkmark {
    background-color: ${t=>t.theme.color.neutral.dark[3]};
    border-color: ${t=>t.theme.color.neutral.dark[2]};
  }
  :host(.soma-checkbox.disabled) input:checked ~ .checkmark {
    background-color: ${t=>t.theme.color.neutral.light[2]};
    border-color: ${t=>t.theme.color.neutral.light[2]};
  }
  :host(.soma-checkbox.inverse.disabled) input:checked ~ .checkmark {
    background-color: ${t=>t.theme.color.neutral.dark[2]};
    border-color: ${t=>t.theme.color.neutral.dark[2]};
  }
`;var R=function(t,e,o,s){var i,r=arguments.length,n=r<3?e:null===s?s=Object.getOwnPropertyDescriptor(e,o):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(t,e,o,s);else for(var a=t.length-1;a>=0;a--)(i=t[a])&&(n=(r<3?i(n):r>3?i(e,o,n):i(e,o))||n);return r>3&&n&&Object.defineProperty(e,o,n),n};let L=(()=>{class r{constructor(o){t(this,o),this.checked=!1,this.inverse=!1,this.disabled=!1,this.handleClick=t=>{t.preventDefault(),this.disabled||(this.checked=!this.checked,this.somaChange.emit(this.checked))},this.onFocus=()=>{this.somaFocus.emit()},this.onBlur=()=>{this.somaBlur.emit()},this.somaChange=e(this,"soma-change",7),this.somaFocus=e(this,"soma-focus",7),this.somaBlur=e(this,"soma-blur",7)}render(){const{inverse:t,disabled:e,value:i,ariaLabel:r,checked:n,label:a}=this,c=h.combine({root:"soma-checkbox",conditions:{inverse:t,disabled:e}});return o(s,{role:"checkbox",class:c},o("label",{onClick:t=>{t.preventDefault(),this.handleClick(t)},"aria-disabled":e?"true":null,"aria-checked":""+n,"aria-label":r},o("input",{onClick:t=>t.preventDefault(),onFocus:this.onFocus,onBlur:this.onBlur,type:"checkbox",checked:n,disabled:e,value:i}),o("div",{class:"checkmark"}),a?o("span",null,a):null))}componentWillLoad(){}componentWillUpdate(){}connectedCallback(){}disconnectedCallback(){}get el(){return i(this)}}return R([u()],r.prototype,"ariaLabel",void 0),R([S({css:O})],r.prototype,"render",null),r})();const B=E`
  :host(.soma-text-field) {
    display: block;
  }

  label {
    font-size: ${t=>t.theme.font.size.xxs};
    transform: translateY(-14px);
    color: ${t=>t.theme.color.neutral.dark[1]};
    display: block;
    font-family: ${t=>t.theme.font.family.base};
    font-weight: ${t=>t.theme.font.weight.regular};
    left: 16px;
    position: absolute;
    transition: all 0.3s;
    width: 100%;
    top: 50%;
    transform: translateY(-50%);
    cursor: text;
    text-align: left;
  }

  :host(.soma-text-field:hover) label {
    color: ${t=>t.theme.color.neutral.dark[3]};
  }

  :host(.soma-text-field:hover) label.disabled {
    color: ${t=>t.theme.color.neutral.light[2]};
  }

  label.disabled {
    cursor: default;
    color: ${t=>t.theme.color.neutral.light[2]};
  }

  .control {
    background: ${t=>t.theme.color.neutral.light[1]};
    border-radius: ${t=>t.theme.border.radius.default};
    overflow: hidden;
    position: relative;
    width: 100%;
  }

  .bar {
    border-bottom: 2px solid ${t=>t.theme.color.neutral.dark.pure};
    bottom: 0;
    content: "";
    display: block;
    left: 0;
    margin: 0 auto;
    position: absolute;
    right: 0;
    transition: all 0.3s;
    width: 0px;
  }

  .bar.success {
    border-bottom: 2px solid ${t=>t.theme.color.feedback.success};
  }

  .bar.error {
    border-bottom: 2px solid ${t=>t.theme.color.feedback.error};
  }

  input {
    appearance: none;
    background: transparent;
    border: none;
    border-bottom: 2px solid transparent;
    color: ${t=>t.theme.color.neutral.dark[2]};
    display: block;
    font-size: ${t=>t.theme.font.size.xxs};
    outline: 0;
    padding: 26px 16px 10px 16px;
    width: 100%;
    height: 64px;
    box-sizing: border-box;
    -webkit-transition: all 0.1s ease-out;
    transition: all 0.1s ease-out;
  }

  input::-webkit-outer-spin-button,
  input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  input[type=number] {
    -moz-appearance:textfield;
  }

  input:visited {
    background-color: ${t=>t.theme.color.neutral.dark[2]};
  }

  input:active {
    background-color: ${t=>t.theme.color.neutral.light[1]};
  }

  input:disabled {
    background-color: ${t=>t.theme.color.neutral.light[1]};
    color: ${t=>t.theme.color.neutral.light[2]};
  }

  input:-ms-input-placeholder ~ label {
    font-size: ${t=>t.theme.font.size.xxs};
    color: ${t=>t.theme.color.neutral.dark[1]};
    transform: translateY(0);
  }

  input:hover:-ms-input-placeholder ~ label {
    color: ${t=>t.theme.color.neutral.dark[3]};
  }

  input::-ms-clear {
    display: none;
  }

  :host(.soma-text-field.filled) input ~ label {
    font-size: ${t=>t.theme.font.size.us};
    transform: translateY(-20px);
    color: ${t=>t.theme.color.neutral.dark[2]};
  }

  :host(.soma-text-field.filled) input ~ label.success {
    color: ${t=>t.theme.color.feedback.success};
  }

  :host(.soma-text-field.filled) input ~ label.error {
    color: ${t=>t.theme.color.feedback.error};
  }

  input:focus ~ .bar,
  .bar.focus {
    width: 100%;
  }

  input:disabled:-ms-input-placeholder ~ label {
    color: ${t=>t.theme.color.neutral.light[2]};
  }

  input:disabled:placeholder-shown ~ label {
    color: ${t=>t.theme.color.neutral.light[2]};
  }

  .feedback {
    font-family: "Roboto";
    font-size: ${t=>t.theme.font.size.us};
  }

  .feedback.error {
    color: ${t=>t.theme.color.feedback.error};
  }

  .feedback.success {
    color: ${t=>t.theme.color.feedback.success};
  }

  .soma-text-field.error {
    display: block;
    margin-bottom: ${t=>t.theme.spacing.stack.xs};
  }

  :host(.soma-text-field.error) input:placeholder-shown ~ label {
    color: ${t=>t.theme.color.feedback.error};
  }

  :host(.soma-text-field.error) input {
    border-bottom: 2px solid ${t=>t.theme.color.feedback.error};
  }

  :host(.soma-text-field.error) input:focus ~ label {
    color: ${t=>t.theme.color.feedback.error};
    color: ${t=>t.theme.color.feedback.error};
  }

  .control.icon label {
    left: 56px;
  }

  .control.icon input{
    padding-left: 56px;
  }

  .icon-field {
    position: absolute;
    width: 24px;
    height: 24px;
    left: 16px;
    top: 50%;
    transform: translateY(-50%);
  }
`;var A=function(t,e,o,s){var i,r=arguments.length,n=r<3?e:null===s?s=Object.getOwnPropertyDescriptor(e,o):s;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)n=Reflect.decorate(t,e,o,s);else for(var a=t.length-1;a>=0;a--)(i=t[a])&&(n=(r<3?i(n):r>3?i(e,o,n):i(e,o))||n);return r>3&&n&&Object.defineProperty(e,o,n),n};let Y=(()=>{class r{constructor(s){t(this,s),this.type="text",this.disabled=!1,this.getIconColor=t=>t?"theme.color.neutral.light.2":"theme.color.neutral.dark.pure",this.handleChange=t=>{const e=t.target;e&&(this.value=e.value||"",this.somaChange.emit(e.value))},this.renderIcon=(t,e)=>t?o("div",{class:"icon-field"},o("soma-icon",{icon:t,color:this.getIconColor(e),size:"md"})):null,this.getLabelClass=(t,e)=>`${t||""} ${e?"disabled":""}`,this.getBarClass=(t,e)=>`bar ${t||""} ${e?"focus":""}`,this.getFeedbackClass=t=>"feedback "+(t||""),this.getControlClass=t=>"control "+(t?"icon":""),this.onFocus=()=>{var t;null===(t=this.inputEl)||void 0===t||t.focus(),this.inputFocus=!0,this.somaFocus.emit()},this.onBlur=()=>{var t;null===(t=this.inputEl)||void 0===t||t.blur(),this.inputFocus=!1,this.somaBlur.emit()},this.getInputEl=()=>this.el.shadowRoot?this.el.shadowRoot.querySelector("input"):this.el.querySelector("input"),this.somaChange=e(this,"soma-change",7),this.somaFocus=e(this,"soma-focus",7),this.somaBlur=e(this,"soma-blur",7)}componentDidRender(){this.inputEl=this.getInputEl()}render(){const{icon:t,type:e,disabled:i,value:r,ariaLabel:n,label:a,feedback:c,message:l,name:u,inputId:b}=this,d=h.combine({root:"soma-text-field",conditions:{filled:!!r||this.inputFocus}});return o(s,{class:d},o("div",{class:this.getControlClass(t)},o("input",{id:b,type:e,placeholder:"",disabled:i,onInput:this.handleChange,onFocus:this.onFocus,onBlur:this.onBlur,name:u,"aria-disabled":!!i||null,"aria-label":n,value:r}),this.renderIcon(t,i),o("label",{class:this.getLabelClass(c,i),htmlFor:b,onClick:()=>{var t;return null===(t=this.inputEl)||void 0===t?void 0:t.focus()}},a),o("div",{class:this.getBarClass(c,r)})),c&&l&&o("span",{class:this.getFeedbackClass(c)},l))}componentWillLoad(){}componentWillUpdate(){}connectedCallback(){}disconnectedCallback(){}get el(){return i(this)}}return A([u()],r.prototype,"type",void 0),A([u()],r.prototype,"ariaLabel",void 0),A([S({css:B})],r.prototype,"render",null),r})();export{a as legods_button,c as legods_input,L as soma_checkbox,Y as soma_text_field}