import { Host, Element, Component, Prop, Listen, Event, h } from '@stencil/core';
import { getProps, customEvent } from '../../utils';
export class LegoButton {
    constructor() {
        this.styles = {};
        this.variant = "";
        this.disabled = false;
        this.full = false;
        this.flat = false;
        this.component = {
            name: 'legods-button',
            properties: getProps(this.el.attributes),
            styles: this.styles
        };
    }
    handleClick(event) {
        !this.disabled && this.buttonClick.emit(customEvent('buttonClick', this.component, event));
    }
    render() {
        return (h(Host, { style: this.full && { width: `100%` } },
            h("button", Object.assign({}, getProps(this.el.attributes), { class: `
            legods-button 
            ${this.variant && this.variant} 
            ${this.full && 'full'} 
            ${this.flat && 'flat'} 
          `, style: this.styles, disabled: this.disabled }),
                h("slot", null))));
    }
    static get is() { return "legods-button"; }
    static get encapsulation() { return "shadow"; }
    static get originalStyleUrls() { return {
        "$": ["legods-button.scss"]
    }; }
    static get styleUrls() { return {
        "$": ["legods-button.css"]
    }; }
    static get properties() { return {
        "styles": {
            "type": "any",
            "mutable": false,
            "complexType": {
                "original": "any",
                "resolved": "any",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "styles",
            "reflect": false,
            "defaultValue": "{}"
        },
        "variant": {
            "type": "string",
            "mutable": false,
            "complexType": {
                "original": "string",
                "resolved": "string",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "variant",
            "reflect": false,
            "defaultValue": "\"\""
        },
        "disabled": {
            "type": "boolean",
            "mutable": false,
            "complexType": {
                "original": "boolean",
                "resolved": "boolean",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "disabled",
            "reflect": false,
            "defaultValue": "false"
        },
        "full": {
            "type": "boolean",
            "mutable": false,
            "complexType": {
                "original": "boolean",
                "resolved": "boolean",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "full",
            "reflect": false,
            "defaultValue": "false"
        },
        "flat": {
            "type": "boolean",
            "mutable": false,
            "complexType": {
                "original": "boolean",
                "resolved": "boolean",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "flat",
            "reflect": false,
            "defaultValue": "false"
        }
    }; }
    static get events() { return [{
            "method": "buttonClick",
            "name": "buttonClick",
            "bubbles": true,
            "cancelable": true,
            "composed": true,
            "docs": {
                "tags": [],
                "text": ""
            },
            "complexType": {
                "original": "any",
                "resolved": "any",
                "references": {}
            }
        }]; }
    static get elementRef() { return "el"; }
    static get listeners() { return [{
            "name": "click",
            "method": "handleClick",
            "target": undefined,
            "capture": true,
            "passive": false
        }]; }
}
