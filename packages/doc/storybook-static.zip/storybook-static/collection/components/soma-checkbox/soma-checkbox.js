var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Component, Element, Host, Prop, Event, h } from '@stencil/core';
import { Decorators, Utils } from '@lego-ds/utils';
import Adapt from '@lego-ds/js-css';
import SomaCheckboxStyle from './soma-checkbox.style';
let SomaCheckbox = /** @class */ (() => {
    class SomaCheckbox {
        constructor() {
            /**
              Define se está selecionado
            */
            this.checked = false;
            /**
              Modifica o tema para inverse
            */
            this.inverse = false;
            /**
              Desabilita o componente
            */
            this.disabled = false;
            this.handleClick = (event) => {
                event.preventDefault();
                if (this.disabled)
                    return;
                this.checked = !this.checked;
                this.somaChange.emit(this.checked);
            };
            this.onFocus = () => {
                this.somaFocus.emit();
            };
            this.onBlur = () => {
                this.somaBlur.emit();
            };
        }
        render() {
            const { inverse, disabled, value, ariaLabel, checked, label } = this;
            const className = Utils.Classes.combine({
                root: 'soma-checkbox',
                conditions: {
                    inverse,
                    disabled,
                }
            });
            return (h(Host, { role: "checkbox", class: className },
                h("label", { onClick: (e) => {
                        e.preventDefault();
                        this.handleClick(e);
                    }, "aria-disabled": disabled ? 'true' : null, "aria-checked": `${checked}`, "aria-label": ariaLabel },
                    h("input", { onClick: e => e.preventDefault(), onFocus: this.onFocus, onBlur: this.onBlur, type: "checkbox", checked: checked, disabled: disabled, value: value }),
                    h("div", { class: "checkmark" }),
                    label ? h("span", null, label) : null)));
        }
        componentWillLoad() { }
        componentWillUpdate() { }
        connectedCallback() { }
        disconnectedCallback() { }
        static get is() { return "soma-checkbox"; }
        static get encapsulation() { return "shadow"; }
        static get properties() { return {
            "checked": {
                "type": "boolean",
                "mutable": false,
                "complexType": {
                    "original": "boolean",
                    "resolved": "boolean",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "Define se est\u00E1 selecionado"
                },
                "attribute": "checked",
                "reflect": false,
                "defaultValue": "false"
            },
            "inverse": {
                "type": "boolean",
                "mutable": false,
                "complexType": {
                    "original": "boolean",
                    "resolved": "boolean",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "Modifica o tema para inverse"
                },
                "attribute": "inverse",
                "reflect": false,
                "defaultValue": "false"
            },
            "disabled": {
                "type": "boolean",
                "mutable": false,
                "complexType": {
                    "original": "boolean",
                    "resolved": "boolean",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "Desabilita o componente"
                },
                "attribute": "disabled",
                "reflect": false,
                "defaultValue": "false"
            },
            "value": {
                "type": "any",
                "mutable": false,
                "complexType": {
                    "original": "any | null",
                    "resolved": "any",
                    "references": {}
                },
                "required": false,
                "optional": true,
                "docs": {
                    "tags": [],
                    "text": "O valor do checkbox"
                },
                "attribute": "value",
                "reflect": false
            },
            "label": {
                "type": "string",
                "mutable": false,
                "complexType": {
                    "original": "string",
                    "resolved": "string",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "Define a `label`"
                },
                "attribute": "label",
                "reflect": false
            },
            "ariaLabel": {
                "type": "string",
                "mutable": false,
                "complexType": {
                    "original": "string",
                    "resolved": "string",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "[*] Define string de acessibilidade `aria-label`"
                },
                "attribute": "aria-label",
                "reflect": false
            }
        }; }
        static get events() { return [{
                "method": "somaChange",
                "name": "soma-change",
                "bubbles": true,
                "cancelable": true,
                "composed": true,
                "docs": {
                    "tags": [],
                    "text": "Emite um `CustomEvent` com `checked` quando `checked` muda"
                },
                "complexType": {
                    "original": "boolean",
                    "resolved": "boolean",
                    "references": {}
                }
            }, {
                "method": "somaFocus",
                "name": "soma-focus",
                "bubbles": true,
                "cancelable": true,
                "composed": true,
                "docs": {
                    "tags": [],
                    "text": "Emite um `CustomEvent` quando h\u00E1 foco"
                },
                "complexType": {
                    "original": "void",
                    "resolved": "void",
                    "references": {}
                }
            }, {
                "method": "somaBlur",
                "name": "soma-blur",
                "bubbles": true,
                "cancelable": true,
                "composed": true,
                "docs": {
                    "tags": [],
                    "text": "Emite um `CustomEvent` quando h\u00E1 perda de foco"
                },
                "complexType": {
                    "original": "void",
                    "resolved": "void",
                    "references": {}
                }
            }]; }
        static get elementRef() { return "el"; }
    }
    __decorate([
        Decorators.Required()
    ], SomaCheckbox.prototype, "ariaLabel", void 0);
    __decorate([
        Adapt({
            css: SomaCheckboxStyle
        })
    ], SomaCheckbox.prototype, "render", null);
    return SomaCheckbox;
})();
export { SomaCheckbox };
