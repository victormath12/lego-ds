var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { Component, Host, Prop, Element, Event, h, State } from '@stencil/core';
import Adapt from '@lego-ds/js-css';
import { Decorators, Utils } from '@lego-ds/utils';
import SomaInputStyle from './soma-text-field.style';
let SomaTextField = /** @class */ (() => {
    class SomaTextField {
        constructor() {
            /**
              [*] Define tipo de input
            */
            this.type = "text";
            /**
              Desabilita o componente
            */
            this.disabled = false;
            this.getIconColor = (disabled) => disabled ? "theme.color.neutral.light.2" : "theme.color.neutral.dark.pure";
            this.handleChange = (event) => {
                const input = event.target;
                if (input) {
                    this.value = input.value || '';
                    this.somaChange.emit(input.value);
                }
            };
            this.renderIcon = (icon, disabled) => {
                if (!icon) {
                    return null;
                }
                return (h("div", { class: "icon-field" },
                    h("soma-icon", { icon: icon, color: this.getIconColor(disabled), size: "md" })));
            };
            this.getLabelClass = (feedback, disabled) => `${feedback ? feedback : ''} ${disabled ? 'disabled' : ''}`;
            this.getBarClass = (feedback, focus) => `bar ${feedback ? feedback : ''} ${focus ? 'focus' : ''}`;
            this.getFeedbackClass = (feedback) => `feedback ${feedback ? feedback : ''}`;
            this.getControlClass = (icon) => `control ${icon ? 'icon' : ''}`;
            this.onFocus = () => {
                var _a;
                (_a = this.inputEl) === null || _a === void 0 ? void 0 : _a.focus();
                this.inputFocus = true;
                this.somaFocus.emit();
            };
            this.onBlur = () => {
                var _a;
                (_a = this.inputEl) === null || _a === void 0 ? void 0 : _a.blur();
                this.inputFocus = false;
                this.somaBlur.emit();
            };
            this.getInputEl = () => {
                if (this.el.shadowRoot) {
                    return this.el.shadowRoot.querySelector('input');
                }
                return this.el.querySelector('input');
            };
        }
        componentDidRender() {
            this.inputEl = this.getInputEl();
        }
        render() {
            const { icon, type, disabled, value, ariaLabel, label, feedback, message, name, inputId } = this;
            const className = Utils.Classes.combine({
                root: 'soma-text-field',
                conditions: {
                    filled: !!value || this.inputFocus
                }
            });
            return (h(Host, { class: className },
                h("div", { class: this.getControlClass(icon) },
                    h("input", { id: inputId, type: type, placeholder: "", disabled: disabled, onInput: this.handleChange, onFocus: this.onFocus, onBlur: this.onBlur, name: name, "aria-disabled": disabled ? true : null, "aria-label": ariaLabel, value: value }),
                    this.renderIcon(icon, disabled),
                    h("label", { class: this.getLabelClass(feedback, disabled), htmlFor: inputId, onClick: () => { var _a; return (_a = this.inputEl) === null || _a === void 0 ? void 0 : _a.focus(); } }, label),
                    h("div", { class: this.getBarClass(feedback, value) })),
                feedback &&
                    message &&
                    h("span", { class: this.getFeedbackClass(feedback) }, message)));
        }
        componentWillLoad() { }
        componentWillUpdate() { }
        connectedCallback() { }
        disconnectedCallback() { }
        static get is() { return "soma-text-field"; }
        static get encapsulation() { return "shadow"; }
        static get properties() { return {
            "type": {
                "type": "string",
                "mutable": false,
                "complexType": {
                    "original": "string",
                    "resolved": "string",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "[*] Define tipo de input"
                },
                "attribute": "type",
                "reflect": false,
                "defaultValue": "\"text\""
            },
            "message": {
                "type": "string",
                "mutable": false,
                "complexType": {
                    "original": "string",
                    "resolved": "string",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "Define mensagem de feedback"
                },
                "attribute": "message",
                "reflect": false
            },
            "feedback": {
                "type": "string",
                "mutable": false,
                "complexType": {
                    "original": "string",
                    "resolved": "string",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "Define tipo do feedback: `error`, `success`"
                },
                "attribute": "feedback",
                "reflect": false
            },
            "inputId": {
                "type": "string",
                "mutable": false,
                "complexType": {
                    "original": "string",
                    "resolved": "string",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "Define `id` da input e `for` do label"
                },
                "attribute": "input-id",
                "reflect": false
            },
            "label": {
                "type": "string",
                "mutable": false,
                "complexType": {
                    "original": "string",
                    "resolved": "string",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "Define a label do componente"
                },
                "attribute": "label",
                "reflect": false
            },
            "value": {
                "type": "string",
                "mutable": false,
                "complexType": {
                    "original": "string",
                    "resolved": "string",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "Valor de input"
                },
                "attribute": "value",
                "reflect": false
            },
            "disabled": {
                "type": "boolean",
                "mutable": false,
                "complexType": {
                    "original": "boolean",
                    "resolved": "boolean",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "Desabilita o componente"
                },
                "attribute": "disabled",
                "reflect": false,
                "defaultValue": "false"
            },
            "name": {
                "type": "string",
                "mutable": false,
                "complexType": {
                    "original": "string",
                    "resolved": "string",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "O nome do controle que \u00E9 submetido junto com form data"
                },
                "attribute": "name",
                "reflect": false
            },
            "icon": {
                "type": "string",
                "mutable": false,
                "complexType": {
                    "original": "string",
                    "resolved": "string",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "Habilita \u00EDcone no componente"
                },
                "attribute": "icon",
                "reflect": false
            },
            "ariaLabel": {
                "type": "string",
                "mutable": false,
                "complexType": {
                    "original": "string",
                    "resolved": "string",
                    "references": {}
                },
                "required": false,
                "optional": false,
                "docs": {
                    "tags": [],
                    "text": "[*] Define string de acessibilidade `aria-label`"
                },
                "attribute": "aria-label",
                "reflect": false
            }
        }; }
        static get states() { return {
            "inputFocus": {}
        }; }
        static get events() { return [{
                "method": "somaChange",
                "name": "soma-change",
                "bubbles": true,
                "cancelable": true,
                "composed": true,
                "docs": {
                    "tags": [],
                    "text": "Emite um `CustomEvent` com o `value` quando h\u00E1 input"
                },
                "complexType": {
                    "original": "string",
                    "resolved": "string",
                    "references": {}
                }
            }, {
                "method": "somaFocus",
                "name": "soma-focus",
                "bubbles": true,
                "cancelable": true,
                "composed": true,
                "docs": {
                    "tags": [],
                    "text": "Emite um `CustomEvent` quando h\u00E1 foco"
                },
                "complexType": {
                    "original": "void",
                    "resolved": "void",
                    "references": {}
                }
            }, {
                "method": "somaBlur",
                "name": "soma-blur",
                "bubbles": true,
                "cancelable": true,
                "composed": true,
                "docs": {
                    "tags": [],
                    "text": "Emite um `CustomEvent` quando h\u00E1 perda de foco"
                },
                "complexType": {
                    "original": "void",
                    "resolved": "void",
                    "references": {}
                }
            }]; }
        static get elementRef() { return "el"; }
    }
    __decorate([
        Decorators.Required()
    ], SomaTextField.prototype, "type", void 0);
    __decorate([
        Decorators.Required()
    ], SomaTextField.prototype, "ariaLabel", void 0);
    __decorate([
        Adapt({
            css: SomaInputStyle
        })
    ], SomaTextField.prototype, "render", null);
    return SomaTextField;
})();
export { SomaTextField };
