const customEvent = (eventName, component, event) => ({
    component: component.name,
    props: Object.assign(Object.assign({}, component.properties), { styles: component.styles }),
    eventName,
    event
});
export default customEvent;
