declare const customEvent: (eventName: any, component: any, event: any) => {
    component: any;
    props: any;
    eventName: any;
    event: any;
};
export default customEvent;
