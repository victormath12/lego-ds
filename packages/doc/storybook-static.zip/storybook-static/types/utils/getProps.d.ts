declare const getProps: (nodeMap: NamedNodeMap) => {};
export default getProps;
