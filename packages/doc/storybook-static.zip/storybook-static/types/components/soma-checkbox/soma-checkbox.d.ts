import { EventEmitter } from '../../stencil-public-runtime';
export declare class SomaCheckbox {
    el: HTMLElement;
    /**
      Define se está selecionado
    */
    checked: boolean;
    /**
      Modifica o tema para inverse
    */
    inverse: boolean;
    /**
      Desabilita o componente
    */
    disabled: boolean;
    /**
      O valor do checkbox
    */
    value?: any | null;
    /**
      Define a `label`
    */
    label: string;
    /**
      [*] Define string de acessibilidade `aria-label`
    */
    ariaLabel: string;
    /**
      Emite um `CustomEvent` com `checked` quando `checked` muda
     */
    somaChange: EventEmitter<boolean>;
    /**
      Emite um `CustomEvent` quando há foco
     */
    somaFocus: EventEmitter<void>;
    /**
      Emite um `CustomEvent` quando há perda de foco
     */
    somaBlur: EventEmitter<void>;
    private handleClick;
    private onFocus;
    private onBlur;
    render(): any;
    componentWillLoad(): void;
    componentWillUpdate(): void;
    connectedCallback(): void;
    disconnectedCallback(): void;
}
