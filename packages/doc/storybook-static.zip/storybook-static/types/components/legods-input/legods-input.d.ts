export declare class LegoInput {
    el: any;
    label: string;
    value: string;
    inputId: string;
    name: string;
    disabled: boolean;
    render(): any;
}
