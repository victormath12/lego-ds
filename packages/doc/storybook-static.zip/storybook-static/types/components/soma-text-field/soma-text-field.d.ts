import { EventEmitter } from '../../stencil-public-runtime';
export declare class SomaTextField {
    el: HTMLElement;
    /**
      [*] Define tipo de input
    */
    type: string;
    /**
      Define mensagem de feedback
    */
    message: string;
    /**
      Define tipo do feedback: `error`, `success`
    */
    feedback: string;
    /**
      Define `id` da input e `for` do label
    */
    inputId: string;
    /**
      Define a label do componente
    */
    label: string;
    /**
      Valor de input
    */
    value: string;
    /**
      Desabilita o componente
    */
    disabled: boolean;
    /**
     * O nome do controle que é submetido junto com form data
     */
    name: string;
    /**
      Habilita ícone no componente
    */
    icon: string;
    /**
      [*] Define string de acessibilidade `aria-label`
    */
    ariaLabel: string;
    /**
     Emite um `CustomEvent` com o `value` quando há input
   */
    somaChange: EventEmitter<string>;
    /**
       Emite um `CustomEvent` quando há foco
    */
    somaFocus: EventEmitter<void>;
    /**
       Emite um `CustomEvent` quando há perda de foco
    */
    somaBlur: EventEmitter<void>;
    /**
      Input Focus
    */
    inputFocus: boolean;
    /**
      Input HTML element
    */
    private inputEl;
    private getIconColor;
    private handleChange;
    private renderIcon;
    private getLabelClass;
    private getBarClass;
    private getFeedbackClass;
    private getControlClass;
    private onFocus;
    private onBlur;
    private getInputEl;
    componentDidRender(): void;
    render(): any;
    componentWillLoad(): void;
    componentWillUpdate(): void;
    connectedCallback(): void;
    disconnectedCallback(): void;
}
