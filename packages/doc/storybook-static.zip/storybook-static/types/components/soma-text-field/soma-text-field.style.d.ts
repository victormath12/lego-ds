declare const _default: (props: any, markup: string) => import("@lego-ds/js-css/dist/types/adapt").IAdaptation;
export default _default;
