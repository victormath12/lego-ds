import { EventEmitter } from '../../stencil-public-runtime';
export declare class LegoButton {
    el: any;
    styles: any;
    variant: string;
    disabled: boolean;
    full: boolean;
    flat: boolean;
    buttonClick: EventEmitter<any>;
    component: {
        name: string;
        properties: any;
        styles: any;
    };
    handleClick(event: any): void;
    render(): any;
}
